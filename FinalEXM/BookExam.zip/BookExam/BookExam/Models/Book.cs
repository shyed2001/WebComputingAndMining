﻿namespace BookExam.Models
{
    public class Book
    {
        public int BookID { get; set; }
        public string BookName { get; set; }

        public string BookAddress { get; set; }
    }
}
