﻿namespace BookExam.Models
{
    public class Research
    {
        public int ResearchID { get; set; }
        public string ResearchTitle { get; set; }

        public string PrincipleInvestigator { get; set; }
        public string Fund { get; set; }
    }
}
